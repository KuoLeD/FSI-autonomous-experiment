﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace jog
{
   
    public partial class Form1 : Form
    {
        short sRtn;
        short axis=1;
        bool[] en=new bool[8];
        uint clk;
        double vel, prfvel, encvel, prfpos, encpos;
        double uacc,dacc;
        double stopvel;
        
        TcpListener listener;
        Thread listenerThread;

        
        int pos;
        double newSpeed;
        double newUAcc, newDAcc, newlimit;
        double posset;
        double accset;
        double decset;
        double realpos;
        double realvel;
        double[] pValue = new double[6];
        double encpos0;
        string filename;
        gts.mc.TJogPrm jog;
        public Form1()
        {
            InitializeComponent();
            StartNetworkListener();
        }
        string mainip = "192.168.1.101"; //反馈端ip
        int mainport = 55001;
        int finish = 0;
        double limit;
        //
        //接收端程序
        //
        private void StartNetworkListener()
        {
            listenerThread= new Thread(() =>
            {
                IPAddress locaAddr = IPAddress.Any;
                int port = 55000;
                
                listener= new TcpListener(locaAddr, port);
                listener.Start();
                Console.WriteLine(string.Format("Listening port {0}:",port));

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    IPEndPoint clientEndpoint= (IPEndPoint)client.Client.RemoteEndPoint;
                    NetworkStream stream = client.GetStream();
                    Console.WriteLine(string.Format("connected by client {0}:",clientEndpoint.Address ));

                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string command = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    Console.WriteLine(command);
                    // 处理接收到的指令
                    ProcessCommand(command);

                    client.Close();
                 }
              });
              listenerThread.IsBackground = true;
              listenerThread.Start();
        }
        private void ProcessCommand(string command)
        {
            
            // 解析指令
            if (command.StartsWith("SET_SPEED:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out newSpeed))
                {
                    textBox1.Invoke(new Action(() => textBox1.Text = parts[1])); // 设置新的速度
       
                }
            }
            else if (command.StartsWith("SET_ACC:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out newUAcc))
                {

                    textBox3.Invoke(new Action(() => textBox3.Text = parts[1])); // 设置新的加速度
                }
            }
            else if (command.StartsWith("SET_DEC:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out newDAcc))
                {
                    textBox4.Invoke(new Action(() => textBox4.Text = parts[1])); // 设置新的减速度
                }
            }
            else if (command.StartsWith("DISTANCE:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out newlimit))
                {
                    textBox6.Invoke(new Action(() => textBox6.Text = parts[1])); // 设置新的限位
                    limit = Convert.ToDouble(this.textBox6.Text);
                }
            }
            else if (command == "INIT")
            {
                gts.mc.GT_Reset();  // 初始化
            }
            else if (command == "RESET")
            {
                gts.mc.GT_LoadConfig("GT800_test.cfg");//下载配置文件
                gts.mc.GT_ClrSts(1, 8);//清除各轴报警和限位
                gts.mc.GT_PrfJog(axis);//设置为jog模式 // 
            }
            else if (command == "SETZERO")
            {
                gts.mc.GT_ZeroPos(1, 8); // 设置位置为0
                finish = 0;
            }
            else if (command == "ENABLE_SERVO")
            {
                gts.mc.GT_AxisOn(axis);  // 启用伺服
                button5.Invoke(new Action(() => button5.Text = "伺服关闭"));
                en[axis - 1] = !en[axis - 1];
            }
            else if (command == "DISABLE_SERVO")
            {
                gts.mc.GT_AxisOff(axis); // 禁用伺服
                button5.Invoke(new Action(() => button5.Text = "伺服使能"));
                en[axis - 1] = !en[axis - 1];
            }
            else if (command == "MOVE_POS")  //正向
            {
                ///读取参数
                vel = Convert.ToDouble(this.textBox1.Text);
                vel = vel * 10 / (0.224 / 5);
                accset = Convert.ToDouble(this.textBox3.Text);
                jog.acc = accset * 0.01 / (0.224 / 5);
                decset = Convert.ToDouble(this.textBox4.Text);
                jog.dec = decset * 0.01 / (0.224 / 5);

                gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数
                gts.mc.GT_SetVel(axis, -vel);//设置目标速度
                gts.mc.GT_Update(axis);//更新轴运动
            }
            else if (command == "MOVE_NEG")  //负向
            {
                vel = Convert.ToDouble(this.textBox1.Text);
                vel = vel * 10 / (0.224 / 5);
                accset = Convert.ToDouble(this.textBox3.Text);
                jog.acc = accset * 0.01 / (0.224 / 5);
                decset = Convert.ToDouble(this.textBox4.Text);
                jog.dec = decset * 0.01 / (0.224 / 5);

                gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数
                gts.mc.GT_SetVel(axis, vel);//设置目标速度
                gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
            }
            
             else if (command == "STOP")  //负向
            {
                gts.mc.GT_Stop(1 << (axis - 1), 0); //停止
                SendCommand(mainip, mainport, string.Format("FINISHMOVE:{0}", encpos));
             }
        }
        //
        //发送端程序
        //
        private void SendCommand(string ip, int port, string command,int timeout=2000)
        {
            try
            {
                using (TcpClient client = new TcpClient(ip, port))
                {
                    
                    Console.WriteLine(string.Format("connect server {0}:", ip));
                    //获取网络流
                    using (NetworkStream stream = client.GetStream())
                    {
                        byte[] data = Encoding.ASCII.GetBytes(command);
                        stream.Write(data, 0, data.Length);
                        Console.WriteLine(string.Format(command));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(string.Format("find error when sending command {0}:", e.Message));
            }
         }
        //加载界面
        //
        private void Form1_Load(object sender, EventArgs e)
        {
            gts.mc.GT_Open(0,1);//打开运动控制卡
           

        }
        //
        //复位
        //
        private void button6_Click(object sender, EventArgs e)
        {
            gts.mc.GT_Reset();
        }
        //
        //初始化
        //
        private void button1_Click(object sender, EventArgs e)
        {
            gts.mc.GT_LoadConfig("GT800_test.cfg");//下载配置文件
            gts.mc.GT_ClrSts(1,8);//清除各轴报警和限位
            gts.mc.GT_PrfJog(axis);//设置为jog模式
            
            
        }
        //
        //伺服使能
        //
        private void button5_Click(object sender, EventArgs e)
        {
            
                if (!en[axis-1])
                {
                    gts.mc.GT_AxisOn(axis);//上伺服
                    this.button5.Text = "伺服关闭";
                }
                if (en[axis-1])
                {
                    gts.mc.GT_AxisOff(axis);//下伺服
                    this.button5.Text = "伺服使能";
                }
                en[axis - 1] = !en[axis - 1];
          
        }
        //
        //刷新状态
        //
        private void timer1_Tick(object sender, EventArgs e)
        {
            limit = Convert.ToDouble(this.textBox6.Text);
            encpos0 = gts.mc.GT_GetEncPos(axis,out encpos,1,out clk);
            encpos = encpos / 10000 * 0.224 / 5;
            this.textBox2.Text = Math.Round(encpos, 1).ToString();
            //Console.WriteLine(encpos);
            //读取实际速度并显示
            gts.mc.GT_GetEncVel(axis, out encvel, 1, out clk);
            encvel = encvel /10 * 0.224 / 5;
            //Console.WriteLine(encvel);
            this.textBox5.Text = Math.Round(encvel, 6).ToString();

            if (encpos > Math.Abs(limit) || encpos < -Math.Abs(limit))
            {
                gts.mc.GT_Stop(1 << (axis - 1), 0);
                if (finish ==0)
                {
                    SendCommand(mainip, mainport, string.Format("FINISHMOVE:{0}", encpos));
                    finish = 1;
                }
                
            }
   
           
            if (!en[axis - 1])
            {
                this.button5.Text = "伺服使能";
            }
            if (en[axis - 1])
            {
                this.button5.Text = "伺服关闭";
            }
          
        }
        //
        //位置清零
        //
        private void button4_Click(object sender, EventArgs e)
        {
            gts.mc.GT_ZeroPos(1,8);
            finish = 0;
        }
        //
      
     
        //
        //停止运动
        //
        private void button7_Click(object sender, EventArgs e)
        {
            gts.mc.GT_Stop(1 << (axis - 1), 0);
            //SendCommand(mainip, mainport, string.Format("FINISHMOVE:", encpos)); // 发送信号，注释掉则不会卡顿
        }

        //
        //正向运动
        //
        private void button3_Click(object sender, EventArgs e)
        {
            ///读取参数
            vel = Convert.ToDouble(this.textBox1.Text);
            vel = vel * 10 / (0.224/5);
            accset = Convert.ToDouble(this.textBox3.Text);
            jog.acc = accset * 0.01 / (0.224 / 5);
            decset = Convert.ToDouble(this.textBox4.Text);
            jog.dec = decset * 0.01 / (0.224 / 5);


            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, -vel);//设置目标速度

            gts.mc.GT_Update(axis);//更新轴运动
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ///读取参数
            vel =0;
            accset = Convert.ToDouble(this.textBox3.Text);
            jog.acc = accset * 0.01 / (0.224 / 5);
            decset = Convert.ToDouble(this.textBox4.Text);
            jog.dec = decset * 0.01 / (0.224 / 5);


            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, vel);//设置目标速度

            gts.mc.GT_Update(axis);//更新轴运动
        }
        //
        //负向运动
        //
        private void button2_Click(object sender, EventArgs e)
        {
            vel = Convert.ToDouble(this.textBox1.Text);
            vel = vel * 10 / (0.224 / 5);
            accset = Convert.ToDouble(this.textBox3.Text);
            jog.acc = accset * 0.01 / (0.224 / 5);
            decset = Convert.ToDouble(this.textBox4.Text);
            jog.dec = decset * 0.01 / (0.224 / 5);



            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, vel);//设置目标速度

            gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
        }

        private void button9_Click(object sender, EventArgs e)
        {
            vel = 0;
            accset = Convert.ToDouble(this.textBox3.Text);
            jog.acc = accset * 0.01 / (0.224 / 5);
            decset = Convert.ToDouble(this.textBox4.Text);
            jog.dec = decset * 0.01 / (0.224 / 5);



            gts.mc.GT_SetJogPrm(axis, ref jog);//设置jog运动参数

            gts.mc.GT_SetVel(axis, vel);//设置目标速度

            gts.mc.GT_Update(1 << (axis - 1));//更新轴运动
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
       

        
    }
}
