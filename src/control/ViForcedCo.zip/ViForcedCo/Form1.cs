﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
//using System.Math;

namespace Forcedoscillation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            StartNetworkListener();
        }

        short sRtn;
        const short AXIS = 1;
        const short AXIS0 = 2;
        double freq, amplitude, freq2, amplitude2, phi, AA, tphi;
        double time, time2;
        double pos, pos2, phireal,pbool;
        short space;
        int LOOP;
        double initialCFPos, initialILPos;
        double finalCFPos, finalILPos;
        short start;
        double dt = 0.001;
        double[] pValue = new double[8];
        double vel1, vel2;
        string filename;
        double realtimeh = 0;
        double a1, f1, a2, f2, theta, cycletime;
        string name0;
        bool measureStop = false;
        string mainip = "192.168.1.101";
        int mainport = 55001;
        TcpListener listener;
        Thread listenerThread;
        //
        //接收端程序
        //

        private void StartNetworkListener()
        {
            listenerThread = new Thread(() =>
            {
                IPAddress locaAddr = IPAddress.Any;
                int port = 55000;

                listener = new TcpListener(locaAddr, port);
                listener.Start();
                Console.WriteLine(string.Format("Listening port {0}:", port));

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    IPEndPoint clientEndpoint = (IPEndPoint)client.Client.RemoteEndPoint;
                    NetworkStream stream = client.GetStream();
                    Console.WriteLine(string.Format("connected by client {0}:", clientEndpoint.Address));

                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string command = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    Console.WriteLine(command);
                    // 处理接收到的指令
                    ProcessCommand(command);

                    client.Close();
                }
            });
            listenerThread.IsBackground = true;
            listenerThread.Start();
        }
        private void ProcessCommand(string command)
        {

            // 解析指令
            if (command.StartsWith("SET_NAME:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2)
                {
                    textBox1.Invoke(new Action(() => textBox1.Text = parts[1])); // 设置新的name
                }
            }
            else if (command.StartsWith("SET_A1:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out a1))
                {

                    Amplitude_os.Invoke(new Action(() => Amplitude_os.Text = parts[1])); // 设置新的a1
                }
            }
            else if (command.StartsWith("SET_F1:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out f1))
                {
                    double t1 = f1;
                    string t1string = t1.ToString("F3");
                    period_os.Invoke(new Action(() => period_os.Text = t1string)); // 设置新的f1
                }
            }
            else if (command.StartsWith("SET_A2:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out a2))
                {

                    Amplitude_se.Invoke(new Action(() => Amplitude_se.Text = parts[1])); // 设置新的a2
                }
            }
            else if (command.StartsWith("SET_F2:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out f2))
                {
                    double f02 = f2;
                    string f2string = f02.ToString("F3");
                    period_se.Invoke(new Action(() => period_se.Text = f2string)); // 设置新的f2
                }
            }
            else if (command.StartsWith("SET_THETA:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out theta))
                {

                    PHASEBOX.Invoke(new Action(() => PHASEBOX.Text = parts[1])); // 设置新的theta
                }
            }
            else if (command.StartsWith("SET_CYCLE:"))
            {
                string[] parts = command.Split(':');
                if (parts.Length == 2 && double.TryParse(parts[1], out cycletime))
                {

                    Loop_os.Invoke(new Action(() => Loop_os.Text = parts[1])); // 设置新的循环次数
                }
            }
            else if (command == "ENABLE_CONTROL")
            {
                sRtn = gts.mc.GT_Open(0, 1);
                measureStop = false;
                //系统复位
                sRtn += gts.mc.GT_Reset();
                sRtn += gts.mc.GT_LoadConfig(Environment.CurrentDirectory + "\\GTS8000728.cfg");


                sRtn += gts.mc.GT_ClrSts(1, 8);
                sRtn = gts.mc.GT_AxisOn(AXIS);
                sRtn = gts.mc.GT_AxisOn(AXIS0);
                sRtn += gts.mc.GT_ZeroPos(AXIS, 1);
                sRtn += gts.mc.GT_ZeroPos(AXIS0, 1);
                sRtn += gts.mc.GT_PrfPt(AXIS, gts.mc.PT_MODE_DYNAMIC);
                sRtn += gts.mc.GT_PrfPt(AXIS0, gts.mc.PT_MODE_DYNAMIC);
                Thread th1 = new Thread(Measured);
                th1.IsBackground = true;
                th1.Start();
            }
            else if (command == "DISABLE_CONTROL")
            {
                gts.mc.GT_AxisOff(AXIS);
                gts.mc.GT_AxisOff(AXIS0);
                measureStop = true;
                gts.mc.GT_Close();
            }
            else if (command == "MOVE")
            {
                //sRtn += gts.mc.

                // sRtn += gts.mc.GT_SetPtMemory(AXIS, 1);

                sRtn += gts.mc.GT_PtClear(AXIS, 0);
                sRtn += gts.mc.GT_PtClear(AXIS0, 0);
                Thread th = new Thread(pt_run);
                th.IsBackground = true;
                th.Start();
            }

        }
        //
        //发送端程序
        //
        private void SendCommand(string ip, int port, string command)
        {
            try
            {
                using (TcpClient client = new TcpClient(ip, port))
                {
                    Console.WriteLine(string.Format("connect server {0}:", ip));
                    //获取网络流
                    using (NetworkStream stream = client.GetStream())
                    {
                        byte[] data = Encoding.ASCII.GetBytes(command);
                        stream.Write(data, 0, data.Length);
                        Console.WriteLine(string.Format(command));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(string.Format("find error when sending command {0}:", e.Message));
            }
        }
        //
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceFrequency(out long lpFrequency);
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        //

        private void chushi_Click(object sender, EventArgs e)
        {

            sRtn = gts.mc.GT_Open(0, 1);
            measureStop = false;
            //系统复位
            sRtn += gts.mc.GT_Reset();
            sRtn += gts.mc.GT_LoadConfig(Environment.CurrentDirectory + "\\GTS8000728.cfg");


            sRtn += gts.mc.GT_ClrSts(1, 8);
            sRtn = gts.mc.GT_AxisOn(AXIS);
            sRtn = gts.mc.GT_AxisOn(AXIS0);
            sRtn += gts.mc.GT_ZeroPos(AXIS, 1);
            sRtn += gts.mc.GT_ZeroPos(AXIS0, 1);
            sRtn += gts.mc.GT_PrfPt(AXIS, gts.mc.PT_MODE_DYNAMIC);
            sRtn += gts.mc.GT_PrfPt(AXIS0, gts.mc.PT_MODE_DYNAMIC);
            Thread th1 = new Thread(Measured);
            th1.IsBackground = true;
            th1.Start();

        }

        private void endcontrol_Click(object sender, EventArgs e)
        {
            gts.mc.GT_AxisOff(AXIS);
            gts.mc.GT_AxisOff(AXIS0);
            gts.mc.GT_Close();
            measureStop = true;


        }

        private void startmove_Click(object sender, EventArgs e)
        {

            //sRtn += gts.mc.

            // sRtn += gts.mc.GT_SetPtMemory(AXIS, 1);

            sRtn += gts.mc.GT_PtClear(AXIS, 0);
            sRtn += gts.mc.GT_PtClear(AXIS0, 0);
            Thread th = new Thread(pt_run);
            th.IsBackground = true;
            th.Start();


        }

        private void pt_run()
        {
            uint clk;
            short count = 1;
            int[] sts = new int[8];
            double[] prfPos = new double[8], prfVel = new double[8], encPos = new double[8];
            double tt;
            //int loop=1;

            time = 0;
            time2 = 0;
            //start = 0;
            vel1 = vel2 = 0;
            pos = 0;
            tphi = 0;
            pbool = 0;
            amplitude = Convert.ToDouble(Amplitude_os.Text);
            freq = Convert.ToDouble(period_os.Text);
            LOOP = Convert.ToInt32(Loop_os.Text);
            amplitude2 = Convert.ToDouble(Amplitude_se.Text);
            freq2 = Convert.ToDouble(period_se.Text);
            phi = Convert.ToDouble(PHASEBOX.Text);
            phireal = (phi / 180 + 3 / 2);
            tt = phireal / 2 / freq2;
            

            while (true)
            {
                sRtn = gts.mc.GT_PtSpace(AXIS, out space, 0);
                if (space > 0)
                {
                    time = time + dt;

                    // CF方向强迫运动
                    pos = (amplitude * (Math.Sin(2 * Math.PI * freq * time)) * 50000 / 0.125);//Convert.ToInt32
                    vel1 = (2 * Math.PI * freq) * amplitude * Math.Cos(2 * Math.PI * freq * time) * 50000 / 0.125;
                    // IL 方向强迫运动
                    pos2 = (amplitude2 * (Math.Sin(2 * Math.PI * freq2 * time + phi / 180 * Math.PI)) * 50000 / 0.125);//Convert.ToInt32
                    vel2 = (2 * Math.PI * freq2) * amplitude2 * Math.Cos(2 * Math.PI * freq2 * time + phi / 180 * Math.PI) * 50000 / 0.125;

                    //if (time <= (Convert.ToDouble(1 / freq) * Convert.ToDouble(LOOP)))
                    //{
                    //    // IL 方向强迫运动
                    //    pos2 = (amplitude2 * (1 - Math.Cos((-2) * Math.PI * freq2 * time)) * 50000 / 0.125);//Convert.ToInt32
                    //    vel2 = -(2 * Math.PI * freq2) * amplitude2 * Math.Sin(2 * Math.PI * freq2 * time) * 50000 / 0.125;

                    //}
                    //else
                    //{
                    //    pos2 = 0;//Convert.ToInt32
                    //    vel2 = 0;

                    //}

                    //tphi = 2 * Math.PI * freq2 * time;
                    //if (tphi >= phireal * Math.PI || pbool == 1)
                    //{
                    //    time2 = time2 + dt;
                    //    // CF方向强迫运动
                    //    pos = (amplitude * (1 - Math.Cos((-2) * Math.PI * freq * time2)) * 50000 / 0.125);//Convert.ToInt32
                    //    vel1 = -(2 * Math.PI * freq) * amplitude * Math.Sin(2 * Math.PI * freq * time2) * 50000 / 0.125;
                    //    pbool = 1;
                    //}
                    //else
                    //{
                    //    pos = 0;
                    //    vel1 = 0;
                    //}
                    
                    if (time <= (Convert.ToDouble(1 / freq) * Convert.ToDouble(LOOP)))
                    {
                        //if (time < (Convert.ToDouble(1 / freq) * Convert.ToDouble(LOOP)))
                        //{
                        
                            sRtn = gts.mc.GT_PtData(AXIS, Convert.ToDouble(pos), Convert.ToInt32(time * 1000), 1, 0);
                            sRtn = gts.mc.GT_PtData(AXIS0, Convert.ToDouble(pos2), Convert.ToInt32(time * 1000), 1, 0);
                            
                        //}
                        //else
                        //{
                        //    sRtn = gts.mc.GT_PtData(AXIS0, Convert.ToDouble(pos2), Convert.ToInt32(time * 1000), 1, 0);
                        //}

                    }

                    else
                    {
                        
                        measureStop = true;
                        start = 0;
                        break;
                        

                    }
                }

                else if (0 == start)
                {
                    sRtn = gts.mc.GT_PtStart(1 << (AXIS - 1), 0 << (AXIS - 1));
                    sRtn = gts.mc.GT_PtStart(1 << (AXIS0 - 1), 0 << (AXIS0 - 1));
                    start = 1;

                }
                //System.Threading.Thread.Sleep(10);
                //sRtn = gts.mc.GT_GetSts(AXIS, out sts[0], count, out clk);
                // sRtn = gts.mc.GT_GetPrfPos(AXIS, out prfPos[0], 8, out clk);
                // sRtn = gts.mc.GT_GetPrfVel(AXIS, out prfVel[0], 8, out clk);
                //sRtn = gts.mc.GT_GetPrfPos(AXIS0, out prfPos11, count, out clk);
                //sRtn = gts.mc.GT_GetPrfPos(4, out prfPos11, count, out clk);
                //sRtn = gts.mc.GT_PtData(AXIS, Convert.ToDouble(prfPos11), Convert.ToInt32(time * 1000), 0, 0);

            }


        }



        private void initialmove_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Amplitude_os_TextChanged(object sender, EventArgs e)
        {

        }

        private void period_os_TextChanged(object sender, EventArgs e)
        {

        }

        private void Loop_os_TextChanged(object sender, EventArgs e)
        {

        }

        private void Measured()
        {

            uint clk;
            short count = 1;
            int[] sts = new int[8];
            double[] prfPos = new double[8], prfVel = new double[8], encPos = new double[8];
            double prfpos1;
            double prfpos2;
            double encpos1;
            double encpos2;
            //double timed = 0;
            //filename = "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + textBox1.Text + ".txt";
            filename = DateTime.Now.ToString("yyyyMMddHHmmss") + textBox1.Text + ".txt";
            string storePath = @"D:\DPQ\主机-联合控制\Test实验";
            string fullPath = Path.Combine(storePath, filename);
            StreamWriter sw = new StreamWriter(fullPath);
            //StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + filename);
            while (!measureStop)
            {
                long frequency;
                bool success = QueryPerformanceFrequency(out frequency);

                long startTime, endTime;
                QueryPerformanceCounter(out startTime);
                double elapsedTime = 0;
                sRtn = gts.mc.GT_GetSts(AXIS, out sts[0], count, out clk);
                sRtn = gts.mc.GT_GetPrfPos(AXIS, out prfPos[0], 8, out clk);
                sRtn = gts.mc.GT_GetPrfVel(AXIS, out prfVel[0], 8, out clk);
                sRtn = gts.mc.GT_GetEncPos(AXIS, out encPos[0], 8, out clk);
                prfpos1 = prfPos[0];
                prfpos2 = prfPos[1];
                encpos1 = encPos[0];
                encpos2 = encPos[1];
                gts.mc.GT_GetAdc(1, out pValue[0], 8, out clk);
                //gts.mc.GT_GetAdc(1, out pValue2, count, out clk);
                //gts.mc.GT_GetAdc(1, out pValue3, count, out clk);
                //gts.mc.GT_GetAdc(1, out pValue4, count, out clk);
                //gts.mc.GT_GetAdc(1, out pValue5, count, out clk);
                //gts.mc.GT_GetAdc(1, out pValue6, count, out clk);
                sw.Write(Convert.ToInt32(clk));
                sw.Write(" ");
                sw.Write(prfpos1.ToString());
                sw.Write(" ");
                sw.Write(prfpos2.ToString());
                sw.Write(" ");
                sw.Write(encpos1.ToString());
                sw.Write(" ");
                sw.Write(encpos2.ToString());
                sw.Write(" ");
                sw.Write(prfVel[0].ToString());
                sw.Write(" ");
                sw.Write((pValue[0] * 50 / (10 * 0.402 / 2)).ToString());//F1X
                sw.Write(" ");
                sw.Write((pValue[1] * 50 / (10 * 0.361 / 2)).ToString());//F1Y
                sw.Write(" ");
                sw.Write((pValue[2] * 50 / (10 * 0.397 / 2)).ToString());//F3X
                sw.Write(" ");
                sw.Write((pValue[3] * 50 / (10 * 0.361 / 2)).ToString());//F3y
                sw.Write(" ");
                sw.Write((pValue[4] * 50 / (10 * 0.397 / 2)).ToString());//F2X
                sw.Write(" ");
                sw.Write((pValue[5] * 50 / (10 * 0.364 / 2)).ToString());//F2Y
                sw.Write(" ");
                sw.Write((pValue[6] * 50 / (10 * 0.361 / 2)).ToString());//F4Y
                sw.Write(" ");
                sw.Write((pValue[7] * 50 / (10 * 0.402 / 2)).ToString());//F4X
                sw.Write(" ");
                sw.Write(realtimeh.ToString());//-0.35094
                sw.Write(" ");
                //sw.Write((pValue[0]*500/5.12*1.04).ToString());//-0.30786
                //sw.Write(" ");
                //sw.Write((pValue[1]*500/4.9545*1.06).ToString());//-0.35094
                //sw.Write(" ");
                //sw.Write((pValue[2]*500/4.373).ToString());//+0.34885
                //sw.Write(" ");
                //sw.Write((pValue[3] * 500 / 5.06325*1.038).ToString());//-0.51105
                //sw.Write(" ");
                //sw.Write((pValue[4]*500/4.58845*1.038).ToString());//+0.07324
                //sw.Write(" ");
                //sw.Write((pValue[5]*500/4.4041).ToString());//-0.61225
                sw.Write("\r\n");
                //System.Threading.Thread.Sleep(20);
                while (elapsedTime < 1)
                {
                    QueryPerformanceCounter(out endTime);
                    long duration = endTime - startTime;
                    elapsedTime = (double)duration / frequency * 1000;
                }

                realtimeh = realtimeh + elapsedTime;

            }
            sw.Close();
            SendCommand(mainip, mainport, string.Format("FINISHCONTROL"));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PHASEBOX_TextChanged(object sender, EventArgs e)
        {

        }









    }
}
